package com.supplyframe.mapreduce;

public enum LogCounter {
	PARSE_ERROR, FIELDS_BLANK, REDUCE_TOTAL_SESSION_WRITE, NON_OPENX_DATA;
}
